import React, { useState, useEffect } from 'react';
import { MapPin, AlertCircle } from 'lucide-react';
import { Map } from './Map';
import { Coordinates } from '../types';

interface FlightFormProps {
  onSubmit: (license: string, startTime: string, endTime: string, coords: Coordinates) => void;
  isSubmitting: boolean;
  error: string | null;
  onErrorClear: () => void;
}

export const FlightForm: React.FC<FlightFormProps> = ({ onSubmit, isSubmitting, error, onErrorClear }) => {
  const [licenseSuffix, setLicenseSuffix] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [coords, setCoords] = useState<Coordinates | null>(null);
  const [todayFormatted, setTodayFormatted] = useState('');

  // Set today's date on mount
  useEffect(() => {
    const now = new Date();
    // Format DD/MM/YYYY for display
    const day = String(now.getDate()).padStart(2, '0');
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const year = now.getFullYear();
    setTodayFormatted(`${day}/${month}/${year}`);
    
    // Default Map Location (Colombo)
    if (!coords) {
        setCoords({ lat: 6.9271, lng: 79.8612 });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleLocateMe = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCoords({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
          onErrorClear();
        },
        (error) => {
          console.error("Error:", error);
          alert("Could not get your location. Please use the map.");
        }
      );
    } else {
      alert("Geolocation is not supported by this browser.");
    }
  };

  const handleTimeInput = (value: string, setter: (val: string) => void) => {
    // Basic formatting HH:MM
    let v = value.replace(/\D/g, '').slice(0, 4);
    if (v.length >= 2) v = v.slice(0, 2) + ':' + v.slice(2);
    setter(v);
    onErrorClear();
  };

  const handleLicenseChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.toUpperCase();
    
    // Allow only alphanumeric and forward slash
    val = val.replace(/[^A-Z0-9/]/g, '');

    // Auto-insert slash logic: 
    // If string has letters followed immediately by a number, insert slash
    // Only if slash is not already there to avoid double slashing or messing up edits
    if (!val.includes('/') && val.length > 0) {
        // Find transition from Letter to Number
        const match = val.match(/([A-Z]+)(\d+)/);
        if (match) {
             val = match[1] + '/' + match[2];
        }
    }

    setLicenseSuffix(val);
    onErrorClear();
  };

  const handleSubmit = () => {
    if (!licenseSuffix || !startTime || !endTime || !coords) {
      alert("Please fill all fields and select a location");
      return;
    }
    
    const fullLicense = `CAASL/DR/${licenseSuffix}`;

    if (startTime.length < 5 || endTime.length < 5) {
      alert("Please enter complete Time");
      return;
    }
    onSubmit(fullLicense, startTime, endTime, coords);
  };

  return (
    <div className="max-w-6xl mx-auto py-6 md:py-10 flex flex-col gap-4 items-center animate-fade-in px-4 w-full">
        
        {/* Input Section (Centered & Compact) */}
        <div className="w-full max-w-xl flex flex-col gap-4 items-center">
            
            {/* License Input */}
            <div className="w-full flex justify-center">
                <div className="w-full max-w-md relative">
                    <div 
                        className="bg-[#4472c4] rounded-md shadow-sm overflow-hidden flex items-center justify-center h-14 px-4 cursor-text hover:bg-[#3d66b0] transition-colors" 
                        onClick={() => document.getElementById('license-input')?.focus()}
                    >
                        <div className="flex items-center justify-center w-full">
                            <span className="text-white/90 text-lg font-medium tracking-wide whitespace-nowrap select-none">CAASL/DR/</span>
                            <input 
                                id="license-input"
                                type="text" 
                                value={licenseSuffix}
                                onChange={handleLicenseChange}
                                placeholder="LO/7486" 
                                className="bg-transparent text-white text-lg placeholder-white/50 outline-none border-none uppercase w-32 ml-0.5 text-left"
                                autoComplete="off"
                            />
                        </div>
                    </div>
                </div>
            </div>

            {/* Date and Time Inputs */}
            <div className="w-full max-w-md flex flex-col gap-4 items-center">
                
                {/* Date Selection - NON-EDITABLE */}
                <div className="bg-[#3d66b0] rounded-md p-3 w-full flex flex-col justify-between min-h-[80px] relative shadow-sm cursor-not-allowed opacity-90">
                    <input 
                        type="text" 
                        value={todayFormatted}
                        readOnly
                        disabled
                        className="w-full bg-transparent text-white/80 text-center text-lg outline-none border-none p-0 mb-1 cursor-not-allowed"
                    />
                    <div className="text-white/70 text-xs md:text-sm text-center font-medium border-t border-white/20 pt-1 mt-1">
                        Flight Date
                    </div>
                </div>

                {/* Time Range */}
                <div className="flex gap-4 w-full justify-center">
                    {/* Start Time */}
                    <div className="bg-[#4472c4] rounded-md p-3 w-full flex flex-col justify-between min-h-[80px] relative shadow-sm group hover:bg-[#3d66b0] transition-colors">
                        <input 
                            type="text" 
                            inputMode="numeric" 
                            placeholder="HH:MM" 
                            maxLength={5} 
                            value={startTime}
                            onChange={(e) => handleTimeInput(e.target.value, setStartTime)}
                            className="w-full bg-transparent text-white text-center text-lg outline-none border-none p-0 mb-1 placeholder-white/50"
                        />
                        <div className="text-white/90 text-xs md:text-sm text-center font-medium border-t border-white/20 pt-1 mt-1">Start Time</div>
                    </div>
                    {/* End Time */}
                    <div className="bg-[#4472c4] rounded-md p-3 w-full flex flex-col justify-between min-h-[80px] relative shadow-sm group hover:bg-[#3d66b0] transition-colors">
                        <input 
                            type="text" 
                            inputMode="numeric" 
                            placeholder="HH:MM" 
                            maxLength={5} 
                            value={endTime}
                            onChange={(e) => handleTimeInput(e.target.value, setEndTime)}
                            className="w-full bg-transparent text-white text-center text-lg outline-none border-none p-0 mb-1 placeholder-white/50"
                        />
                        <div className="text-white/90 text-xs md:text-sm text-center font-medium border-t border-white/20 pt-1 mt-1">End Time</div>
                    </div>
                </div>
            </div>

            {/* Locate Me Button */}
            <button 
                onClick={handleLocateMe} 
                className="bg-[#4472c4] hover:bg-[#335fa8] text-white h-14 px-8 text-lg w-full max-w-xs flex items-center gap-2 justify-center shadow-sm rounded-md transition-colors"
            >
                Locate me <MapPin className="h-5 w-5" />
            </button>
        </div>

        {/* Map Container */}
        <div className="w-full">
            <Map 
                selectedCoords={coords} 
                onLocationSelect={(c) => { setCoords(c); onErrorClear(); }} 
            />
        </div>

        {/* Error Message Box */}
        {error && (
            <div className="w-full max-w-xs bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative flex items-start gap-2 animate-fade-in text-sm shadow-sm">
                <AlertCircle className="h-5 w-5 flex-shrink-0 mt-0.5" />
                <span className="font-medium">{error}</span>
            </div>
        )}

        {/* Lodge a flight Button */}
        <button 
            onClick={handleSubmit} 
            disabled={isSubmitting}
            className={`bg-[#4472c4] hover:bg-[#335fa8] text-white h-14 px-12 text-lg w-full max-w-xs shadow-md transition-all rounded-md ${isSubmitting ? 'opacity-70 cursor-wait' : 'hover:scale-105'}`}
        >
            {isSubmitting ? 'Verifying...' : 'Lodge a flight'}
        </button>
    </div>
  );
};