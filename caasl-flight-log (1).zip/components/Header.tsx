import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="bg-white py-2 px-4 md:px-8 border-b border-gray-200">
        <div className="container mx-auto flex flex-col md:flex-row justify-between items-center gap-2 md:gap-0">
            <div className="flex items-center gap-3 w-full md:w-auto justify-center md:justify-start">
                <img src="https://i.imgur.com/8Q5a4dD.png" alt="CAA Logo" className="h-12 md:h-20 w-auto object-contain" onError={(e) => e.currentTarget.style.display = 'none'} />
                <div className="text-center md:text-left">
                    <h1 className="text-sm xs:text-base md:text-2xl font-serif text-gray-800 tracking-tight font-bold whitespace-nowrap leading-tight">
                        Civil Aviation Authority <span className="text-gray-600 font-normal">of Sri Lanka</span>
                    </h1>
                </div>
            </div>
            
            <div className="text-xs md:text-sm flex gap-3 text-blue-600 font-medium w-full md:w-auto justify-center md:justify-end">
                <a href="#" className="hover:underline">සිංහල</a>
                <span className="text-gray-300">|</span>
                <a href="#" className="hover:underline">தமிழ்</a>
                <span className="text-gray-300">|</span>
                <a href="#" className="hover:underline font-bold">English</a>
            </div>
        </div>
    </header>
  );
};
