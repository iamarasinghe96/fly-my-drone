import React, { useEffect, useRef, useState } from 'react';
import { Coordinates, RestrictedZone } from '../types';
import { Loader2, WifiOff, Search } from 'lucide-react';
import { fetchRestrictedZones } from '../services/api';

declare global {
  interface Window {
    google: any;
  }
}

interface MapProps {
  selectedCoords: Coordinates | null;
  onLocationSelect: (coords: Coordinates) => void;
}

// Permanent Restricted Zones (CAA Map Replication)
const PERMANENT_ZONES: RestrictedZone[] = [
    // --- Airports (Red) ---
    { lat: 7.1808, lng: 79.8841, radius: 5000, name: "Bandaranaike Intl Airport (VCBI)", type: "Restricted" },
    { lat: 6.8222, lng: 79.8845, radius: 5000, name: "Ratmalana Airport (VCCC)", type: "Restricted" },
    { lat: 6.2916, lng: 81.1228, radius: 5000, name: "Mattala Rajapaksa Intl Airport (VCRI)", type: "Restricted" },
    { lat: 9.7933, lng: 80.0694, radius: 5000, name: "Jaffna Intl Airport (VCCJ)", type: "Restricted" },
    { lat: 8.5393, lng: 81.1803, radius: 5000, name: "China Bay Airport (VCCT)", type: "Restricted" },
    { lat: 7.7058, lng: 81.6766, radius: 5000, name: "Batticaloa Airport (VCCB)", type: "Restricted" },
    { lat: 8.3090, lng: 80.4285, radius: 5000, name: "Anuradhapura Airport (VCCA)", type: "Restricted" },
    { lat: 5.9936, lng: 80.3204, radius: 5000, name: "Koggala Airport (VCCK)", type: "Restricted" },
    { lat: 7.9546, lng: 81.6749, radius: 4000, name: "Hingurakgoda Airport (VCCH)", type: "Restricted" },
    { lat: 8.0500, lng: 79.7500, radius: 3000, name: "Palavi Airport", type: "Restricted" },
    { lat: 7.6333, lng: 80.7167, radius: 3000, name: "Sigiriya Airport (VCCS)", type: "Restricted" },
    { lat: 6.2917, lng: 81.2333, radius: 4000, name: "Weerawila Airport (VCCW)", type: "Restricted" },
    { lat: 7.3333, lng: 81.6333, radius: 3000, name: "Ampara Airport (VCCG)", type: "Restricted" },
    { lat: 8.7167, lng: 80.5000, radius: 3000, name: "Vavuniya Airport (VCCV)", type: "Restricted" },

    // --- High Security Zones (Red) ---
    { lat: 6.9344, lng: 79.8428, radius: 3000, name: "Colombo City Restricted Zone (VTP1)", type: "Restricted" },
    { lat: 6.9147, lng: 79.9729, radius: 2000, name: "Parliament Complex (VTP2)", type: "Restricted" },
    { lat: 7.2936, lng: 80.6413, radius: 1000, name: "Sri Dalada Maligawa (Temple of the Tooth)", type: "Restricted" },
    { lat: 8.0167, lng: 79.7167, radius: 2500, name: "Norochcholai Power Plant", type: "Restricted" },
    { lat: 6.9667, lng: 79.9167, radius: 2000, name: "Sapugaskanda Oil Refinery", type: "Restricted" },
    { lat: 6.9319, lng: 79.8540, radius: 1000, name: "Colombo Port", type: "Restricted" },
    
    // --- Sensitive / Warning Zones (Orange) ---
    { lat: 7.2333, lng: 80.7833, radius: 1500, name: "Victoria Dam", type: "Warning" },
    { lat: 7.1667, lng: 80.7667, radius: 1500, name: "Randenigala Dam", type: "Warning" },
    { lat: 6.8406, lng: 80.0211, radius: 1000, name: "Panagoda Army Cantonment", type: "Warning" }
];

export const Map: React.FC<MapProps> = ({ selectedCoords, onLocationSelect }) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const markerRef = useRef<any>(null);
  const circlesRef = useRef<any[]>([]);
  
  const [restrictedZones, setRestrictedZones] = useState<RestrictedZone[]>(PERMANENT_ZONES);
  const [dataSource, setDataSource] = useState<'loading' | 'live' | 'offline'>('loading');
  
  // Default: Colombo
  const defaultPos = { lat: 6.9271, lng: 79.8612 };

  // Fetch Dynamic Zones on Mount and Merge with Permanent
  useEffect(() => {
    const loadZones = async () => {
        try {
            setDataSource('loading');
            const apiZones = await fetchRestrictedZones();

            if (apiZones && apiZones.length > 0) {
                // Combine permanent zones with API zones
                setRestrictedZones([...PERMANENT_ZONES, ...apiZones]);
                setDataSource('live');
            } else {
                setDataSource('offline');
                setRestrictedZones(PERMANENT_ZONES);
            }
        } catch (error) {
            console.error("Error loading zones:", error);
            setDataSource('offline');
            setRestrictedZones(PERMANENT_ZONES);
        }
    };
    loadZones();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Initialize Map
  useEffect(() => {
    if (!mapRef.current || !window.google) return;

    const initialLat = selectedCoords?.lat || defaultPos.lat;
    const initialLng = selectedCoords?.lng || defaultPos.lng;

    // 1. Create Map
    const map = new window.google.maps.Map(mapRef.current, {
      center: { lat: initialLat, lng: initialLng },
      zoom: 13,
      mapTypeControl: false,
      streetViewControl: false,
      fullscreenControl: true,
      styles: [
        {
          featureType: "poi",
          elementType: "labels",
          stylers: [{ visibility: "off" }]
        }
      ]
    });

    mapInstanceRef.current = map;

    // 2. Create Draggable Marker
    const marker = new window.google.maps.Marker({
      position: { lat: initialLat, lng: initialLng },
      map: map,
      draggable: true,
      title: "Flight Location"
    });

    markerRef.current = marker;

    // 3. Marker Drag Listener
    marker.addListener("dragend", () => {
      const position = marker.getPosition();
      onLocationSelect({
        lat: position.lat(),
        lng: position.lng(),
      });
    });

    // 4. Map Click Listener
    map.addListener("click", (e: any) => {
      const clickedLat = e.latLng.lat();
      const clickedLng = e.latLng.lng();
      
      marker.setPosition({ lat: clickedLat, lng: clickedLng });
      onLocationSelect({
        lat: clickedLat,
        lng: clickedLng,
      });
    });

    // 5. Initialize Autocomplete (Search)
    if (searchInputRef.current) {
      const autocomplete = new window.google.maps.places.Autocomplete(searchInputRef.current, {
        componentRestrictions: { country: "lk" },
        fields: ["geometry", "name"],
      });

      autocomplete.addListener("place_changed", () => {
        const place = autocomplete.getPlace();

        if (!place.geometry || !place.geometry.location) {
          alert("No details available for input: '" + place.name + "'");
          return;
        }

        if (place.geometry.viewport) {
          map.fitBounds(place.geometry.viewport);
        } else {
          map.setCenter(place.geometry.location);
          map.setZoom(15);
        }

        const newLat = place.geometry.location.lat();
        const newLng = place.geometry.location.lng();

        marker.setPosition({ lat: newLat, lng: newLng });
        onLocationSelect({ lat: newLat, lng: newLng });
      });
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Sync props (selectedCoords) with Map Marker
  useEffect(() => {
    if (selectedCoords && mapInstanceRef.current && markerRef.current) {
        const newPos = { lat: selectedCoords.lat, lng: selectedCoords.lng };
        markerRef.current.setPosition(newPos);
        
        const mapCenter = mapInstanceRef.current.getCenter();
        const dist = Math.sqrt(
            Math.pow(newPos.lat - mapCenter.lat(), 2) + 
            Math.pow(newPos.lng - mapCenter.lng(), 2)
        );

        if (dist > 0.01) {
             mapInstanceRef.current.panTo(newPos);
        }
    }
  }, [selectedCoords]);

  // Update Restricted Zone Circles
  useEffect(() => {
    if (!mapInstanceRef.current || !window.google) return;

    // Clear old circles
    circlesRef.current.forEach(circle => circle.setMap(null));
    circlesRef.current = [];

    // Draw new circles
    restrictedZones.forEach(zone => {
        const isWarning = zone.type && zone.type.toLowerCase().includes('warning');
        
        const color = isWarning ? '#EA580C' : '#DC2626'; // Orange : Red
        const fillColor = isWarning ? '#F97316' : '#EF4444'; // Orange : Red

        const circle = new window.google.maps.Circle({
            strokeColor: color,
            strokeOpacity: 0.8,
            strokeWeight: 2,
            fillColor: fillColor,
            fillOpacity: 0.25,
            map: mapInstanceRef.current,
            center: { lat: zone.lat, lng: zone.lng },
            radius: zone.radius, 
            clickable: true
        });

        const infoWindow = new window.google.maps.InfoWindow({
            content: `
              <div style="text-align:center; padding: 5px;">
                <strong style="color: ${color}; display: block; margin-bottom: 4px;">
                  ${isWarning ? 'Warning Zone' : 'Restricted Zone'}
                </strong>
                <span style="font-size: 12px; color: #333;">${zone.name}</span>
              </div>
            `
        });

        circle.addListener("click", (ev: any) => {
            infoWindow.setPosition(ev.latLng);
            infoWindow.open(mapInstanceRef.current);
        });

        circlesRef.current.push(circle);
    });
  }, [restrictedZones]);


  return (
    <div className="w-full mx-auto flex flex-col gap-4">
      {/* Search Bar - Themed Blue */}
      <div className="relative w-full max-w-2xl mx-auto shadow-sm">
        <div className="absolute left-3 top-1/2 -translate-y-1/2 text-white/70 pointer-events-none">
            <Search className="h-4 w-4" />
        </div>
        <input
            ref={searchInputRef}
            type="text"
            placeholder="Search location (e.g. Kandy, Galle Face)"
            className="w-full pl-10 pr-4 py-3 bg-[#4472c4] text-white placeholder-white/70 border-none rounded-md shadow-sm outline-none text-sm transition-all focus:bg-[#3d66b0] hover:bg-[#3d66b0]"
        />
      </div>

      {/* Map Container - Full Width */}
      <div className="relative rounded-lg overflow-hidden border border-gray-300 shadow-md w-full">
          <div 
            ref={mapRef} 
            className="h-[500px] w-full z-0 bg-gray-100"
          />
          
          {/* Data Source Status Indicator */}
          <div className="absolute top-2 right-2 z-[10] pointer-events-none">
             {dataSource === 'loading' && (
                <div className="bg-white/90 backdrop-blur px-2 py-1 rounded text-[10px] text-gray-500 font-medium flex items-center gap-1.5 shadow-sm border border-gray-200">
                    <Loader2 className="h-3 w-3 animate-spin" /> Checking updates...
                </div>
             )}
             {dataSource === 'live' && (
                <div className="bg-white/90 backdrop-blur px-2 py-1 rounded text-[10px] text-green-700 font-medium flex items-center gap-1.5 shadow-sm border border-green-100">
                    <div className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                    </div>
                    Updated
                </div>
             )}
          </div>

          {/* Legend Overlay */}
          <div className="absolute bottom-2 left-2 bg-white/90 backdrop-blur-sm p-2 rounded shadow text-[10px] z-[10] border border-gray-200 pointer-events-none">
             <div className="flex items-center gap-1.5 mb-1">
                <div className="w-3 h-3 rounded-full bg-red-500 border border-white shadow-sm"></div>
                <span className="text-gray-700 font-medium">Flight Location</span>
             </div>
             <div className="flex items-center gap-1.5 mb-1">
                <div className="w-3 h-3 rounded-full bg-red-500/20 border border-red-600"></div>
                <span className="text-gray-700 font-medium">Restricted Zone</span>
             </div>
             <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-full bg-orange-500/20 border border-orange-600"></div>
                <span className="text-gray-700 font-medium">Warning Zone</span>
             </div>
          </div>
      </div>

      <p className="text-xs text-gray-500 text-center font-medium bg-gray-100 py-1.5 px-3 rounded-full self-center">
        {selectedCoords 
          ? `Selected Coordinates: ${selectedCoords.lat.toFixed(4)}, ${selectedCoords.lng.toFixed(4)}`
          : 'Tap on the map to select a location'}
      </p>
    </div>
  );
};