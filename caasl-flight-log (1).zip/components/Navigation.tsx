import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';

export const Navigation: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);

  const navLinks = [
    { name: 'Home', href: 'https://portal.caa.lk/drone/apply-now/report.php', active: false },
    { name: 'Personal Licenses', href: 'https://iamarasinghe96.github.io/licenseverification/', active: false },
    { name: 'Log a flight', href: 'https://iamarasinghe96.github.io/logaflight', active: true },
    { name: 'Pilot Registration', href: 'https://iamarasinghe96.github.io/pilotregistration/', active: false },
  ];

  return (
    <nav className="bg-[#0088cc] text-white shadow-md sticky top-0 z-50">
        <div className="container mx-auto px-4 md:px-8">
            {/* Desktop Menu */}
            <div className="hidden md:flex md:flex-wrap w-full">
                {navLinks.map((link) => (
                    <a 
                        key={link.name}
                        href={link.href} 
                        className={`block px-6 py-4 text-base font-medium transition-colors duration-200 ${link.active ? 'bg-[#006699]' : 'hover:bg-[#0077b3]'}`}
                    >
                        {link.name}
                    </a>
                ))}
            </div>

            {/* Mobile Menu Bar */}
            <div className="md:hidden flex items-center justify-between py-3">
                <span className="font-medium text-sm uppercase tracking-wider opacity-90">Menu</span>
                <button onClick={toggleMobileMenu} className="text-white hover:bg-white/20 p-2 rounded-md">
                    <Menu className="h-6 w-6" />
                </button>
            </div>
        </div>

        {/* Mobile Drawer */}
        {isMobileMenuOpen && (
            <>
                <div className="fixed inset-0 bg-black/80 z-[60]" onClick={toggleMobileMenu}></div>
                <div className="fixed inset-y-0 right-0 z-[70] w-[300px] sm:w-[400px] bg-white shadow-xl flex flex-col animate-fade-in">
                    <div className="bg-[#0088cc] p-6 text-white relative">
                        <button onClick={toggleMobileMenu} className="absolute right-4 top-4 text-white/70 hover:text-white">
                            <X className="h-6 w-6" />
                        </button>
                        <h2 className="text-xl font-semibold mb-1">Civil Aviation Authority</h2>
                        <p className="text-blue-100 text-sm opacity-90">of Sri Lanka</p>
                    </div>

                    <div className="flex flex-col gap-2 px-4 py-4 overflow-y-auto flex-grow">
                        {navLinks.map((link) => (
                            <a 
                                key={link.name}
                                href={link.href} 
                                className={`px-4 py-3 text-base font-medium rounded-xl transition-all duration-200 flex items-center ${link.active ? 'text-[#0088cc] bg-blue-50 ring-1 ring-blue-100 shadow-sm' : 'text-gray-700 hover:bg-gray-50 hover:pl-6'}`}
                            >
                                {link.name}
                            </a>
                        ))}
                    </div>

                    <div className="mt-auto p-6 border-t border-gray-100 bg-white">
                        <p className="text-sm font-medium text-gray-500 mb-3">Language</p>
                        <div className="flex gap-4 text-sm">
                            <a href="#" className="text-blue-600 hover:underline">සිංහල</a>
                            <a href="#" className="text-blue-600 hover:underline">தமிழ்</a>
                            <a href="#" className="text-gray-900 font-bold">English</a>
                        </div>
                    </div>
                </div>
            </>
        )}
    </nav>
  );
};
