import { FlightSubmissionData, FlightLogResponse, LicenseVerificationResponse, RestrictedZone, LicenseCheckResult } from '../types';

const API_LICENSE_URL = "https://script.google.com/macros/s/AKfycbwuhbjXy2sSuPpUFD0sAeuj0Qe8f26bHMwd1KQilMp1f1KTj0LH5MevYCyQKGfbWGSKfg/exec";
const API_FLIGHT_LOG_URL = "https://script.google.com/macros/s/AKfycbzypzwgEPNrUu0vhNnxYAAeY6cA50RqSD4lYjpsj7g087Q-x-G5mkf-ljg1KhBqMJT3yg/exec";

export const verifyLicense = async (licenseNumber: string): Promise<LicenseCheckResult> => {
  try {
    const url = `${API_LICENSE_URL}?action=search&registrationNumber=${encodeURIComponent(licenseNumber.trim())}`;
    const response = await fetch(url, {
        redirect: "follow",
        credentials: 'omit'
    });
    const text = await response.text();
    
    try {
      const data: LicenseVerificationResponse = JSON.parse(text);
      
      if (data.result === 'success') {
          // Check adminStatus (Column U)
          if (data.data && data.data.adminStatus) {
              const status = data.data.adminStatus.toString();
              const statusLower = status.toLowerCase();
              
              // Only allow Active or Approved
              if (statusLower !== 'active' && statusLower !== 'approved') {
                  return { 
                      isValid: false, 
                      message: `License verification failed. Current status: '${status}' (must be Active).` 
                  };
              }
          }
          return { isValid: true };
      } else if (data.result === 'not_found') {
          return { isValid: false, message: "License Number not found. Please check and try again." };
      }
      
      return { isValid: false, message: data.error || "License verification failed." };
      
    } catch (e) {
      console.warn("License verification API returned non-JSON response:", text);
      return { isValid: false, message: "Verification service unavailable. Please try again later." };
    }
  } catch (e) {
    console.error("License verification failed", e);
    return { isValid: false, message: "Network error during verification. Please check your connection." };
  }
};

export const logFlight = async (flightData: FlightSubmissionData): Promise<FlightLogResponse> => {
  // Using specialized headers and redirect mode to handle Google Apps Script POST requests
  const response = await fetch(API_FLIGHT_LOG_URL, {
    method: "POST",
    redirect: "follow",
    credentials: 'omit',
    headers: {
      "Content-Type": "text/plain;charset=utf-8",
    },
    body: JSON.stringify(flightData)
  });

  if (!response.ok) {
    throw new Error("Network response was not ok");
  }

  const text = await response.text();
  try {
    return JSON.parse(text);
  } catch (e) {
    console.error("Log flight API returned non-JSON:", text);
    throw new Error("Invalid response from server");
  }
};

export const fetchRestrictedZones = async (): Promise<RestrictedZone[]> => {
  try {
    // Added timestamp to prevent caching and ensure fresh data from the sheet
    const response = await fetch(`${API_FLIGHT_LOG_URL}?action=getZones&t=${Date.now()}`, {
      redirect: "follow",
      credentials: 'omit'
    });
    
    if (!response.ok) {
        console.warn("API responded with error status:", response.status);
        return [];
    }
    
    const text = await response.text();
    
    // Check if response is "Active" (common default GAS response) or doesn't look like a JSON array
    if (text.trim() === "Active" || !text.trim().startsWith("[")) {
       console.warn("API returned non-JSON restricted zones data (using fallbacks). Response:", text);
       return [];
    }
    
    try {
      const zones: RestrictedZone[] = JSON.parse(text);
      return zones;
    } catch (e) {
      console.warn("Failed to parse restricted zones JSON:", text);
      return [];
    }
  } catch (e) {
    console.error("Failed to fetch restricted zones:", e);
    return [];
  }
};